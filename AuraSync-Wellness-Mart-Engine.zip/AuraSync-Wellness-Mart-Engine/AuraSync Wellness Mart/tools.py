# Tools for Handling Calculations & medical emergency 

from langchain_core.tools import tool

@tool
def calculate(input_str: str) -> str:
    """
    Performs basic arithmetic operations (add, sub, mul, div).
    Expects input in format 'op,a,b' (e.g., 'add,10,20' or 'mul,5,400').
    """
    try:
        parts = [p.strip() for p in input_str.split(",")]
        if len(parts) != 3:
            return "Error: Input must be formatted as 'op,a,b' (e.g., 'add,10,20')."
        
        op, a_str, b_str = parts[0].lower(), parts[1], parts[2]
        a, b = float(a_str), float(b_str)

        if op == "add":
            return f"Calculation Result: {a + b}"
        elif op == "sub":
            return f"Calculation Result: {a - b}"
        elif op == "mul":
            return f"Calculation Result: {a * b}"
        elif op == "div":
            if b == 0:
                return "Error: Division by zero is not allowed."
            return f"Calculation Result: {a / b}"
        else:
            return "Error: Invalid operation specified."
    except Exception as e:
        return f"Calculation Error: {str(e)}"


@tool
def check_medical_safety(query: str) -> str:
    """Evaluates query for emergency symptoms and provides immediate safety guardrails."""
    q_lower = query.lower()
    emergency_keywords = ["103", "fever", "emergency", "severe", "chest pain", "bleeding", "unconscious"]
    
    if any(keyword in q_lower for keyword in emergency_keywords):
        return (
            "SAFETY GUARDRAIL ALERT: High-risk symptoms detected. "
            "Advise the user to seek immediate professional medical care or visit the nearest emergency room in Karachi."
        )
    return "Medical Safety Check Passed: No immediate emergency detected."

