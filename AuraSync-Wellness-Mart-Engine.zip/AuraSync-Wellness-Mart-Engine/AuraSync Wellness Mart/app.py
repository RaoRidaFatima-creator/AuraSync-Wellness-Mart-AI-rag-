# File created for the AuraSync Wellness Mart UI 

import streamlit as st
from rag_pipeline import initialize_vector_store, ask_aurasync

# Page Config
st.set_page_config(page_title="AuraSync Wellness Mart", page_icon="💊", layout="centered")

# Custom CSS for Green/White Theme, Distinct Chat Colors & Hiding Default Icons
st.markdown("""
    <style>
    /* Main Background & Font */
    .stApp {
        background-color: #F4FBF7;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    
    /* Header Styling */
    h1 {
        color: #137333 !important;
        font-weight: 700;
        margin-bottom: 0px;
    }
    
    /* HIDE DEFAULT STREAMLIT USER & ASSISTANT AVATAR ICONS COMPLETELY */
    [data-testid="stChatMessageAvatarUser"], [data-testid="stChatMessageAvatarAssistant"] {
        display: none !important;
    }

    /* Target User Chat Container (Light Green Background & Soft Border) */
    [data-testid="stChatMessage"]:has([data-testid="stChatMessageAvatarUser"]) {
        background-color: #E2F7CB !important;
        border-radius: 12px;
        padding: 10px 15px;
        margin-bottom: 10px;
        border: 1px solid #C4E8A3;
    }

    /* Target Assistant Chat Container (Clean White Background & Soft Border) */
    [data-testid="stChatMessage"]:has([data-testid="stChatMessageAvatarAssistant"]) {
        background-color: #FFFFFF !important;
        border-radius: 12px;
        padding: 10px 15px;
        margin-bottom: 10px;
        border: 1px solid #E0E0E0;
        box-shadow: 0px 2px 5px rgba(0,0,0,0.05);
    }
    </style>
""", unsafe_allow_html=True)

# Title with Capsule Logo
st.title("💊 AuraSync Wellness Mart")
st.markdown("##### Syncing your daily health routine with wellness insights. ")
st.write("---")

# CACHED VECTOR STORE: Loads ONLY ONCE when the app starts
@st.cache_resource
def load_vectorstore():
    try:
        return initialize_vector_store()
    except Exception as e:
        st.error(f"Error loading vector store: {e}")
        return None

vectorstore = load_vectorstore()

if not vectorstore:
    st.info("Please set your `GROQ_API_KEY` in `.env` and add your 5 PDFs in `./knowledge_base/`.")
    st.stop()

# Initialize Chat History in Session State
if "messages" not in st.session_state:
    st.session_state.messages = []

# Display Prior Chat History with Custom Labels
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        if message["role"] == "user":
            st.markdown("**You**")
        else:
            st.markdown("**AuraSync Wellness Mart Assistant**")
            
        st.write(message["content"])
        
        if "docs" in message and message["docs"]:
            with st.expander("🔍 Inspect Retrieved Knowledge Base Evidence"):
                for i, doc in enumerate(message["docs"], 1):
                    st.markdown(f"**Chunk {i} | Source File:** `{doc.metadata.get('source')}`")
                    st.markdown(f"- **Policy Status:** `{doc.metadata.get('status')}`")
                    st.text(doc.page_content)
                    st.divider()

# User Chat Input
user_query = st.chat_input("Type your message here (e.g., Ask about products, prices in PKR, or policies)...")

if user_query:
    # Append & Display User Message
    st.session_state.messages.append({"role": "user", "content": user_query})
    with st.chat_message("user"):
        st.markdown("**You**")
        st.write(user_query)

    # Generate Response
    with st.spinner("AuraSync Assistant is typing..."):
        answer, docs = ask_aurasync(user_query, vectorstore)

    # Append & Display Assistant Response
    st.session_state.messages.append({"role": "assistant", "content": answer, "docs": docs})
    with st.chat_message("assistant"):
        st.markdown("**AuraSync Wellness Mart Assistant**")
        st.markdown(answer, unsafe_allow_html=True)

        if docs:
            with st.expander("🔍 Inspect Retrieved Knowledge Base Evidence"):
                for i, doc in enumerate(docs, 1):
                    st.markdown(f"**Chunk {i} | Source File:** `{doc.metadata.get('source')}`")
                    st.markdown(f"- **Policy Status:** `{doc.metadata.get('status')}`")
                    st.text(doc.page_content)
                    st.divider()